import { useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleLogin(e) {
    e.preventDefault()
    setLoading(true); setError('')
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) setError(error.message)
    setLoading(false)
  }

  return (
    <div style={{
      minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center',
      background:'linear-gradient(135deg, var(--navy) 0%, var(--navy-light) 60%, #2a4a7f 100%)'
    }}>
      <div style={{ width:420, padding:'0 20px' }}>
        <div style={{ textAlign:'center', marginBottom:32 }}>
          <div style={{
            width:64, height:64, background:'var(--gold)', borderRadius:'50%',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontFamily:'Cormorant Garamond,serif', fontWeight:700, fontSize:26,
            color:'var(--navy)', margin:'0 auto 16px'
          }}>ΚΣΤ</div>
          <h1 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:28, fontWeight:700, color:'white', marginBottom:6 }}>Kappa Sigma Tau</h1>
          <p style={{ color:'rgba(255,255,255,0.6)', fontSize:14 }}>Alumni Network — Members Only</p>
        </div>

        <div className="card" style={{ padding:32 }}>
          <h2 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:22, fontWeight:600, color:'var(--navy)', marginBottom:24 }}>Sign In</h2>
          {error && <div className="error-msg" style={{ marginBottom:16 }}>{error}</div>}
          <form onSubmit={handleLogin} style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <div className="form-group">
              <label>Email</label>
              <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@email.com" required />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••" required />
            </div>
            <button type="submit" className="btn btn-primary" disabled={loading} style={{ width:'100%', justifyContent:'center', marginTop:4 }}>
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>
          <p style={{ textAlign:'center', marginTop:20, fontSize:13, color:'var(--gray-400)' }}>
            New member?{' '}
            <Link to="/register" style={{ color:'var(--navy)', fontWeight:500 }}>Create your profile</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
